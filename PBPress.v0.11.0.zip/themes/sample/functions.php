<?php

pb_rewrite_register('other-page', array(
	'title' => '다른페이지',
	'page' => pb_current_theme_path()."other-page.php",
));

?>