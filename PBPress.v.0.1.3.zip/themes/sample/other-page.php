<?php pb_theme_header(); ?>

	<h1 class="text-center" class="text-center">Hello World!<br/>
		<small>여기는 다른 페이지입니다.</small></h1>

<?php pb_theme_footer(); ?>	