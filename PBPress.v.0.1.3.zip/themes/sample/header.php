<!DOCTYPE html>
<html>
<head>
	<title>샘플테마</title>

	<link rel="stylesheet" type="text/css" href="<?=pb_current_theme_url()?>lib/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="<?=pb_current_theme_url()?>lib/css/bootstrap-theme.min.css">

	<script type="text/javascript" src="<?=pb_current_theme_url()?>lib/js/jquery.js"></script>
	<script type="text/javascript" src="<?=pb_current_theme_url()?>lib/js/bootstrap.min.js"></script>
	
</head>
<body>