<?php

// define('PB_DEV', true);
// define('PB_SHOW_DATABASE_ERROR', PB_DEV);

// define('PB_DB_CONNECTION_TYPE', 'mysqli'); //mysql, mysqli

define('PB_DB_HOST', '');
define('PB_DB_USERNAME', '');
define('PB_DB_USERPASS', '');
define('PB_DB_NAME', '');
define('PB_DB_CHARSET', 'utf8');

define("PB_CRYPT_PASSWORD", "~W.7bNa[~$+aeP>u");
// define("PB_CRYPT_ALGORITHM", "");
// define("PB_CRYPT_BITS", "");

define("PB_MULTILINGUAL_THEME", false);
// define("PB_DEFAULT_LOCALE", 'ko_KR');

// define("PB_HTTPS", true);

?>