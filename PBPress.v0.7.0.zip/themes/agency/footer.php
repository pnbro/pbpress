
	<!-- Bootstrap core JavaScript -->
	<script src="<?=pb_current_theme_url()?>vendor/jquery/jquery.min.js"></script>
	<script src="<?=pb_current_theme_url()?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

	<!-- Plugin JavaScript -->
	<script src="<?=pb_current_theme_url()?>vendor/jquery-easing/jquery.easing.min.js"></script>

	<!-- Contact form JavaScript -->
	<script src="<?=pb_current_theme_url()?>js/jqBootstrapValidation.js"></script>
	<script src="<?=pb_current_theme_url()?>js/contact_me.js"></script>

	<!-- Custom scripts for this template -->
	<script src="<?=pb_current_theme_url()?>js/agency.min.js"></script>

</body>

</html>