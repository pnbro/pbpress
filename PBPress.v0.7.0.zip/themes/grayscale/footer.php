
	<!-- Footer -->
	<footer class="bg-black small text-center text-white-50">
		<div class="container">
			Copyright &copy; Your Website 2019
		</div>
	</footer>

	<!-- Bootstrap core JavaScript -->
	<script src="<?=pb_current_theme_url()?>vendor/jquery/jquery.min.js"></script>
	<script src="<?=pb_current_theme_url()?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

	<!-- Plugin JavaScript -->
	<script src="<?=pb_current_theme_url()?>vendor/jquery-easing/jquery.easing.min.js"></script>

	<!-- Custom scripts for this template -->
	<script src="<?=pb_current_theme_url()?>js/grayscale.min.js"></script>

</body>