<?php

define('PB_DEV', true);

define('PB_DB_HOST', '');
define('PB_DB_USERNAME', '');
define('PB_DB_USERPASS', '');
define('PB_DB_NAME', '');
define('PB_DB_CHARSET', 'utf8');

define("PB_CRYPT_PASSWORD", "~W.7bNa[~$+aeP>u");
// define("PB_CRYPT_ALGORITHM", "");
// define("PB_CRYPT_BITS", "");

?>