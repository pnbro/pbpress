
	<footer>
		<hr>
		<div class="text-center">this is footer</div>
	</footer>
	
	<!-- Bootstrap core JavaScript -->
	<script src="<?=pb_current_theme_url()?>lib/js/bootstrap.bundle.min.js"></script>
	<?php pb_foot() ?>
</body>

</html>
