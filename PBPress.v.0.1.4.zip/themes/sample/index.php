<?php pb_theme_header(); ?>

	<h1 class="text-center" class="text-center">Hello World!<br/>
		<small>이 테마는 샘플테마입니다.</small></h1>

	<div class="text-center">
		<a href="<?=pb_home_url('other-page')?>">다른페이지 이동</a>
	</div>

<?php pb_theme_footer(); ?>	