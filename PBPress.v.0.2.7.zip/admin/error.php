<?php 		
		

?>
<link rel="stylesheet" type="text/css" href="<?=PB_LIBRARY_URL?>css/pages/error.css">
<div class="content-group">
	<h1 class="title"><?=$error_title?></h1>
	<div class="subject"><?=$error_message?></div>
</div>