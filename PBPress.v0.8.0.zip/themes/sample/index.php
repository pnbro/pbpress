<?php pb_theme_header(); ?>

	<!-- Page Content -->
	<div class="container">
		<div class="row">
			<div class="col-lg-12 text-center">
				<h1 class="mt-5">Bootstrap 4 템플릿을 이용한 PBPress 샘플테마</h1>
				<p class="lead"><a href="<?=pb_home_url("other-page")?>">다른 페이지 이동</a></p>

				<a href="https://github.com/BlackrockDigital/startbootstrap-bare" target="_blank">startbootstrap-bare 템플릿</a>을 사용했습니다.
			</div>
		</div>
	</div>

<?php pb_theme_footer(); ?>	